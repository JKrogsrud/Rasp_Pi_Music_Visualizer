.. _display:

.. automodule:: librosa.display
