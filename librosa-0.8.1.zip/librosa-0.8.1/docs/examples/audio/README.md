# Audio Examples

The licenses and the origins of the audio files are as follows:

* `sir_duke_slow.mp3` and `sir_duke_fast.mp3` were recorded by Stefan Balke and are released under CC BY 4.0.
